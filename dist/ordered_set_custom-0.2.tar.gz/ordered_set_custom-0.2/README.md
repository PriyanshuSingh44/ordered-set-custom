# ordered-set-custom

A simple utility to create ordered sets from iterables in Python.

This package helps you remove duplicates while preserving the original order of elements — like a set, but in order!

## Installation

```bash
pip install ordered-set-custom
